sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("project2.controller.View1",{onInit:function(){}})});
//# sourceMappingURL=View1.controller.js.map